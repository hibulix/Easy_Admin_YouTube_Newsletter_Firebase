Projet Coupe du Monde en JAVA
===============================================================================================================

Si le projet ne se lance pas en double cliquant sur le fichier Coupe_du_monde_2018.jar
Ouvrez une invite de commande dans ce dossier en cliquant shift + clic droit 
==> Ouvrir une invite de commande

Pour plus de précision ouvrez les images:
-Comment_Lancer_Le_Projet1
-Comment_Lancer_Le_Projet2

Taper la commande suivante: 

java -jar Coupe_du_monde_2018.jar

☛ ★ Si vous aimez le contenu publié par VertinGo Website n'hésitez pas à vous abonner:
1 : S'abonner à ma chaîne You Tube: https://www.youtube.com/channel/UC2g_-ipVjit6ZlACPWG4JvA?sub_confirmation=1
2 : S'abonner à ma page facebook : https://www.facebook.com/vertingo/

